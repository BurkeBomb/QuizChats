# Lessgo — Quick Connect

A single-file web app to skip the small talk. Left pane is for the reader (they can tap anything).
Right pane is your static “Mi bio”. Generate a shareable URL so your picks are pre-filled and locked.

## Run locally
1. Download `index.html` and double-click it to open in your browser (Chrome/Edge/Firefox/Safari).
2. Set your “Mi bio”, click **Share link**, copy the URL, paste it on your dating profiles.

## GitHub Pages
1. Create a new GitHub repo (public or private).
2. Add `index.html` at the repo root.
3. Settings → Pages → Build and deployment → Deploy from **main** branch / **root**.
4. Wait 1–2 minutes. Your site will be live at `https://<user>.github.io/<repo>/`.

## Vercel (recommended)
1. Create a new GitHub repo and push `index.html`.
2. Go to vercel.com → New Project → Import your repo.
3. Framework preset: **Other**. Build command: **None**. Output: **/** (root).
4. Deploy. Your site will be live on a Vercel URL (you can add a custom domain).

## Netlify (alternative)
1. Drag & drop `index.html` into the Netlify app’s **Sites** page _or_ link your Git repo.
2. If linking, build command: **None**; publish directory: **/**.

## Notes
- The share link encodes your “Mi bio” choices in the `?bio=...&locked=1` querystring so the right pane is read-only.
- Use **Unlock** if you need to edit and generate a fresh link.
- **Compact mode** reduces spacing for dense displays.
